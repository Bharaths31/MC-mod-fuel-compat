package dev.iafuelcompat.container;

import net.minecraft.class_1799;

public interface FuelContainerAdapter {
    boolean matches(class_1799 stack);
    int getFuelTime(class_1799 stack);
    class_1799 getContainerReturn(class_1799 stack);
    String getName();
}
