package dev.iafuelcompat.container;

import dev.iafuelcompat.fuel.FuelDefinition;
import dev.iafuelcompat.fuel.FuelRegistry;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class TechRebornCellAdapter implements FuelContainerAdapter {
    @Override
    public boolean matches(class_1799 stack) {
        return class_7923.field_41178.method_10221(stack.method_7909()).toString().equals("techreborn:cell");
    }

    @Override
    public int getFuelTime(class_1799 stack) {
        if (!matches(stack)) return 0;

        Storage<FluidVariant> storage = FluidStorage.ITEM.find(stack, ContainerItemContext.withConstant(stack));
        if (storage != null) {
            for (StorageView<FluidVariant> view : storage) {
                if (!view.isResourceBlank()) {
                    String fluidId = class_7923.field_41173.method_10221(view.getResource().getFluid()).toString();
                    FuelDefinition def = FuelRegistry.getFluidFuel(fluidId);
                    return def != null ? def.getEffectiveBurnTime() : 0;
                }
            }
        }
        return 0;
    }

    @Override
    public class_1799 getContainerReturn(class_1799 stack) {
        class_1792 cell = class_7923.field_41178.method_17966(class_2960.method_60654("techreborn:cell")).orElse(class_1802.field_8162);
        return new class_1799(cell);
    }

    @Override
    public String getName() {
        return "TechRebornCellAdapter";
    }
}
