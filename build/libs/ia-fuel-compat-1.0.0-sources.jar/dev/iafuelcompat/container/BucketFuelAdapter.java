package dev.iafuelcompat.container;

import dev.iafuelcompat.fuel.FuelRegistry;
import net.minecraft.class_1755;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7923;

public class BucketFuelAdapter implements FuelContainerAdapter {
    @Override
    public boolean matches(class_1799 stack) {
        return stack.method_7909() instanceof class_1755;
    }

    @Override
    public int getFuelTime(class_1799 stack) {
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        Integer time = FuelRegistry.getItemFuelTime(itemId);
        return time != null ? time : 0;
    }

    @Override
    public class_1799 getContainerReturn(class_1799 stack) {
        return new class_1799(class_1802.field_8550);
    }

    @Override
    public String getName() {
        return "BucketAdapter";
    }
}
