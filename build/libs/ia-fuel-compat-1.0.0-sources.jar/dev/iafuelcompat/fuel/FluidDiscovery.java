package dev.iafuelcompat.fuel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;

public final class FluidDiscovery {
    private static final Logger LOGGER = LoggerFactory.getLogger("IA-Fuels");

    public static boolean itemExists(String itemId) {
        return resolveItem(itemId, "check").isPresent();
    }

    public static boolean fluidExists(String fluidId) {
        return resolveFluid(fluidId, "check").isPresent();
    }

    public static Optional<class_1792> resolveItem(String itemId, String context) {
        try {
            class_2960 loc = class_2960.method_60654(itemId);
            Optional<class_1792> item = class_7923.field_41178.method_17966(loc);
            if (item.isEmpty() && !context.equals("check")) {
                LOGGER.warn("[IA-Fuels] WARNING: {} → item {} NOT FOUND in registry", context, itemId);
            }
            return item;
        } catch (Exception e) {
            LOGGER.error("[IA-Fuels] Error parsing item ID: {}", itemId, e);
            return Optional.empty();
        }
    }

    public static Optional<class_3611> resolveFluid(String fluidId, String context) {
        try {
            class_2960 loc = class_2960.method_60654(fluidId);
            Optional<class_3611> fluid = class_7923.field_41173.method_17966(loc);
            if (fluid.isEmpty() && !context.equals("check")) {
                LOGGER.warn("[IA-Fuels] WARNING: {} → fluid {} NOT FOUND in registry", context, fluidId);
            }
            return fluid;
        } catch (Exception e) {
            LOGGER.error("[IA-Fuels] Error parsing fluid ID: {}", fluidId, e);
            return Optional.empty();
        }
    }

    public static Optional<String> tryItemCandidates(List<String> candidates, String context) {
        for (String candidate : candidates) {
            if (itemExists(candidate)) {
                return Optional.of(candidate);
            }
        }
        if (!context.equals("check")) {
            LOGGER.warn("[IA-Fuels] WARNING: {} → None of the candidate items found in registry: {}", context, candidates);
        }
        return Optional.empty();
    }
}
