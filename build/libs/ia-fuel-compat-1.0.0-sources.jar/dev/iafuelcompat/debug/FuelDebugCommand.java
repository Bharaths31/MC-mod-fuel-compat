package dev.iafuelcompat.debug;

import com.mojang.brigadier.CommandDispatcher;
import dev.iafuelcompat.container.FuelContainerAdapter;
import dev.iafuelcompat.fuel.FuelDefinition;
import dev.iafuelcompat.fuel.FuelRegistry;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public final class FuelDebugCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("ia-fuels")
                .requires(src -> src.method_9259(2))
                .executes(ctx -> {
                    class_2168 source = ctx.getSource();
                    source.method_9226(() ->
                        class_2561.method_43470("§6=== IA Fuel Compatibility ==="), false);

                    for (FuelDefinition fuel : FuelRegistry.getAllFuels()) {
                        source.method_9226(() -> class_2561.method_43470(String.format(
                            "  §a%s §7(%s) → §e%d ticks §7[%s]",
                            fuel.id(), fuel.provider(),
                            fuel.getEffectiveBurnTime(),
                            fuel.enabled() ? "ON" : "OFF"
                        )), false);
                    }

                    for (FuelContainerAdapter adapter : FuelRegistry.getAdapters()) {
                        source.method_9226(() -> class_2561.method_43470(
                            "  §bAdapter: " + adapter.getName()
                        ), false);
                    }

                    return 1;
                })
        );
    }
}
